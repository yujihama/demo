# AI Agent Test Brief - Employee Expense

Use this dataset to test whether an audit AI agent can perform Employee Expense sample testing from an ExpenseFlow export and supporting evidence.

## Agent task

1. Load `02_population/expenseflow_employee_expense_export.csv`.
2. Test only samples listed in `02_population/selected_samples.csv`.
3. Use the following evaluation criteria:
   - `01_evaluation_criteria/policy_documents_ja/employee_expense_reimbursement_policy_ja.docx`
   - `01_evaluation_criteria/policy_documents_ja/japan_lodging_expense_addendum_ja.docx`
   - `01_evaluation_criteria/structured_rules/common_attributes.csv`
   - `01_evaluation_criteria/structured_rules/expense_type_rules.csv`
4. Use `03_evidence/evidence_index.csv` to identify each sample's ExpenseFlow report and related evidence.
5. Populate `04_template/employee_expense_workpaper_template.xlsx`.
6. Use `05_answer_key_for_scoring` only for scoring after the agent completes the workpaper.
