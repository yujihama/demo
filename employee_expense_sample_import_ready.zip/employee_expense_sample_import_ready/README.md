# Employee Expense Sample - Import Ready

This folder contains the import-ready synthetic Employee Expense sample data. It uses the fictional expense system name `ExpenseFlow` and does not include JSON or PNG files.

## 01_evaluation_criteria

Evaluation criteria used by the AI agent:

- `policy_documents_ja/`: Japanese Word policy documents only
- `structured_rules/common_attributes.csv`: common attributes
- `structured_rules/expense_type_rules.csv`: expense-type rules
- `structured_rules/evaluation_criteria_tables.xlsx`: Excel version of the structured rules

## 02_population

ExpenseFlow export population and selected sample list.

## 03_evidence

ExpenseFlow report PDFs and related supporting evidence. Use `evidence_index.csv` to map samples to evidence files.

## 04_template

Workpaper template and filled example.

## 05_answer_key_for_scoring

Expected results for scoring. Do not provide these files to the AI agent during the test.

## 06_instructions

AI-agent task brief.
