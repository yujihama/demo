# Employee Expense Policy Test Rules

This synthetic policy document defines the rules used by the Employee Expense sample test data. It is not a real company policy.

## Common Attributes

### ATTR-01 - Trace sample to Concur export
- Requirement: Report ID, Entry ID, employee, expense type, transaction date, vendor, and amount in the workpaper agree to the Concur export and Concur report.
- Evidence sources: Concur export; Concur report

### ATTR-02 - Report status and payment status
- Requirement: Expense report status is Approved and payment status is Paid or Scheduled for payment before audit conclusion.
- Evidence sources: Concur export; Concur report approval section

### ATTR-03 - Business purpose
- Requirement: Business purpose is specific enough to identify the business activity, customer/project, or event.
- Evidence sources: Concur report; related event support when applicable

### ATTR-04 - Receipt and amount support
- Requirement: Required receipt or supporting file is present and supports vendor, transaction date, and reimbursed amount.
- Evidence sources: Concur report attachments; receipt or invoice

### ATTR-05 - Manager approval
- Requirement: Report is approved by an authorized manager after submission and before reimbursement; employee did not self-approve.
- Evidence sources: Concur report approval trail

### ATTR-06 - Policy exception approval
- Requirement: Any stated policy exception is supported by documented exception approval from the required approver level.
- Evidence sources: Concur report exception flags; exception approval file

### ATTR-07 - Duplicate expense check
- Requirement: No duplicate expense exists for the same employee with the same or highly similar vendor, date, amount, and receipt number.
- Evidence sources: Concur export population; duplicate candidate support

### ATTR-08 - Accounting classification
- Requirement: Cost center, legal entity, project code, and allocation are reasonable for the employee and business purpose.
- Evidence sources: Concur export; Concur report allocation section

## Expense Type Rules

### Airfare

- AIR-01 - Cabin class
  - Requirement: Economy or coach class is required unless VP approval is attached for business or first class.
  - Threshold: Business/first class requires VP approval
  - Required evidence: Itinerary or e-ticket; approval memo if non-economy
- AIR-02 - Itinerary support
  - Requirement: Itinerary must show traveler name, origin, destination, travel dates, ticket number, and total fare.
  - Threshold: All airfare claims
  - Required evidence: Itinerary or e-ticket receipt

### Hotel/Lodging

- HOT-01 - Nightly rate cap
  - Requirement: Nightly room rate excluding taxes must not exceed the applicable cap unless exception approval is attached.
  - Threshold: USD 250 domestic; USD 300 international
  - Required evidence: Itemized folio; exception approval if over cap
- HOT-02 - Itemized folio
  - Requirement: Hotel folio must itemize room rate, taxes, and non-room charges.
  - Threshold: All lodging claims
  - Required evidence: Hotel folio

### Meal - Individual

- MEAL-01 - Daily individual meal cap
  - Requirement: Individual meal reimbursement must not exceed the daily cap.
  - Threshold: USD 60 per person per day
  - Required evidence: Receipt if over USD 75; Concur report business purpose
- MEAL-02 - Receipt threshold
  - Requirement: Receipt is required for individual meals greater than USD 75.
  - Threshold: > USD 75
  - Required evidence: Receipt when over threshold

### Client Entertainment

- ENT-01 - Attendee list
  - Requirement: Attendee list must include attendee names, company, role, and business relationship.
  - Threshold: All client entertainment claims
  - Required evidence: Attendee list or meeting invite
- ENT-02 - Itemized receipt
  - Requirement: Client entertainment requires an itemized receipt regardless of amount.
  - Threshold: All client entertainment claims
  - Required evidence: Itemized restaurant receipt

### Taxi/Rideshare

- TAXI-01 - Ride details
  - Requirement: Receipt must include date, vendor, amount, origin, destination, and business purpose.
  - Threshold: Receipt required for rides >= USD 25
  - Required evidence: Rideshare receipt
- TAXI-02 - Tip limit
  - Requirement: Tip must not exceed 20% of the fare unless documented reason is approved.
  - Threshold: Tip <= 20% of fare
  - Required evidence: Rideshare receipt detail

### Personal Car Mileage

- MIL-01 - Mileage rate
  - Requirement: Reimbursement amount equals approved miles multiplied by the current mileage rate.
  - Threshold: USD 0.67 per mile
  - Required evidence: Concur mileage line; rate table
- MIL-02 - Route support
  - Requirement: Claimed miles must be supported by a route map or trip log.
  - Threshold: Claimed miles cannot exceed supported route distance without approval
  - Required evidence: Route support or mileage log

### Office Supplies/IT Equipment

- IT-01 - Procurement approval
  - Requirement: IT equipment over USD 500 requires procurement approval before purchase.
  - Threshold: > USD 500
  - Required evidence: Receipt; procurement approval
- IT-02 - Business-use item
  - Requirement: Purchased item must be for business use and assigned to a company user or asset inventory.
  - Threshold: All IT equipment and office supply claims
  - Required evidence: Receipt; asset or assignment note when applicable

### Training/Conference

- TRN-01 - Preapproval
  - Requirement: Training or conference expense over USD 500 requires manager preapproval before registration.
  - Threshold: > USD 500
  - Required evidence: Preapproval memo or learning request
- TRN-02 - Agenda and attendance
  - Requirement: Agenda or registration confirmation must support business relevance and attendance.
  - Threshold: All training/conference claims
  - Required evidence: Agenda, registration confirmation, or attendance certificate
