# AI Agent Test Brief - Employee Expense

Use this dataset to test whether an audit AI agent can perform Employee Expense sample testing from a Concur export and supporting evidence.

## Agent task

1. Load `population/concur_employee_expense_export.csv`.
2. Test only samples listed in `population/selected_samples.csv`.
3. Use `policy/employee_expense_policy.md`, `policy/common_attributes.json`, and `policy/expense_type_rules.csv` as the requirement source.
4. Inspect the Concur Report PDF and related evidence files mapped in `manifest.json`.
5. Populate `workpapers/employee_expense_workpaper_template.xlsx`.
   - Use the `Testing_Matrix` sheet as the single workpaper input sheet.
   - For common attributes, use rows where `CheckCategory = Common Attribute` and `TestID` starts with `ATTR-`.
   - Enter `OK`, `NG`, `N/A`, or `Unable to Conclude` in `AIResult`.
6. Compare agent output to `workpapers/employee_expense_expected_results.csv` or `employee_expense_answer_key.xlsx` for scoring.

## Expected edge cases

- S-EXP-002: hotel nightly cap exception is missing.
- S-EXP-004: client entertainment attendee details are incomplete and business purpose is vague.
- S-EXP-005: duplicate rideshare candidate exists in the export population.
- S-EXP-006: mileage amount uses 120 claimed miles but route support shows only 82 miles.
- S-EXP-007: IT equipment exceeds USD 500 procurement approval threshold and approval is missing.