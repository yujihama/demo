# Employee Expense Concur Sample Test Data

監査AIエージェントの Employee Expense サンプルテスト用の合成データです。実在の個人・会社・Concurデータではありません。

## Contents

- `population/concur_employee_expense_export.csv`: Concurエクスポート母集団
- `population/selected_samples.csv`: テスト対象サンプル
- `evidence/reports/`: 各サンプルのConcur Report PDF/PNG
- `evidence/related_files/`: 領収書、旅程、出席者リスト、重複候補、走行距離サポートなど
- `policy/employee_expense_policy.md`: Expense Type別ルールと共通attributes
- `policy/common_attributes.json`: 共通確認観点
- `policy/expense_type_rules.csv`: Expense Type別要件
- `workpapers/employee_expense_workpaper_template.xlsx`: AIエージェントが記入する調書テンプレート。共通attributesとExpense Type別ルールは `Testing_Matrix` シートに統合されています。
- `workpapers/employee_expense_expected_results.csv`: 採点用の期待結果
- `workpapers/employee_expense_answer_key.xlsx`: 採点用Excel

## Synthetic control design

サンプルは8件で、正常系3件と例外系5件を含みます。意図的にConcur export、Report、関連ファイル、ルール文書を横断しないと検出しづらい論点を混ぜています。

## Workpaper usage

`employee_expense_workpaper_template.xlsx` の `Testing_Matrix` シートは、1行が1サンプル x 1観点です。共通attributesは `CheckCategory = Common Attribute`、Expense Type別ルールは `CheckCategory = Expense Type Rule` で識別します。各行の `AIResult` には `OK`、`NG`、`N/A`、または `Unable to Conclude` を入力できます。根拠メモ、例外コード、証憑引用も同じ行に記入します。