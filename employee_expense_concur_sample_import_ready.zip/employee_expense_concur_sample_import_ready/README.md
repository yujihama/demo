# Employee Expense Concur Sample - Import Ready

このフォルダは、取り込み対象を日本語Word規程とCSV/XLSX中心に整理した版です。JSONファイルは含めていません。

## 01_evaluation_criteria

評価に使う基準類です。

- `policy_documents_ja/`: 規程・マニュアルの日本語Word版のみ
- `structured_rules/common_attributes.csv`: 共通Attribute
- `structured_rules/expense_type_rules.csv`: Expense Type別ルール
- `structured_rules/evaluation_criteria_tables.xlsx`: 上記2つをExcel化したもの

## 02_population

Concurエクスポート母集団と、今回テストするサンプル一覧です。

## 03_evidence

サンプルごとのConcur Reportと関連証憑です。`evidence_index.csv` でサンプルと証憑ファイルの対応を確認できます。

## 04_template

AIエージェントが記入する調書テンプレートと記入例です。

## 05_answer_key_for_scoring

採点・検証用の期待結果です。実テスト時にAIエージェントへ渡さない想定です。

## 06_instructions

AIエージェント向けのタスク説明です。
