# AI Agent Test Brief - Employee Expense

このフォルダは、JSONを使わずに取り込むための整理済みデータです。

## Agent task

1. `02_population/concur_employee_expense_export.csv` を母集団として読み込む。
2. `02_population/selected_samples.csv` に記載されたサンプルのみをテスト対象にする。
3. 評価基準として以下を使用する。
   - `01_evaluation_criteria/policy_documents_ja/employee_expense_reimbursement_policy_ja.docx`
   - `01_evaluation_criteria/policy_documents_ja/japan_lodging_expense_addendum_ja.docx`
   - `01_evaluation_criteria/structured_rules/common_attributes.csv`
   - `01_evaluation_criteria/structured_rules/expense_type_rules.csv`
4. `03_evidence/evidence_index.csv` を使って、各サンプルのConcur Reportと関連証憑を特定する。
5. `04_template/employee_expense_workpaper_template.xlsx` の `Testing_Matrix` シートに結果を記入する。
   - 1行を1サンプルとする。
   - A:Iのサンプルメタデータは維持する。
   - J:Oにエビデンスから抽出したdocument type、date、vendor、amount、currency、remarksを記入する。
   - P:QにExpense Typeに応じて参照したPolicy NameとRequirementsを記入する。
   - R:Wに、必要な事前承認または例外承認の情報を記入する。
   - X:AEに、ATTR-01からATTR-08までの結果を `OK`、`NG`、`N/A`、`Unable to Conclude` のいずれかで記入する。
6. 採点時のみ、`05_answer_key_for_scoring` 配下の期待結果を使用する。

## Expected edge cases

- S-EXP-002: hotel nightly cap exception is missing.
- S-EXP-004: client entertainment attendee details are incomplete and business purpose is vague.
- S-EXP-005: duplicate rideshare candidate exists in the export population.
- S-EXP-006: mileage amount uses 120 claimed miles but route support shows only 82 miles.
- S-EXP-007: IT equipment exceeds USD 500 procurement approval threshold and approval is missing.
